import pymysql
from datetime import datetime, timedelta
import time

# import secret as secret

import sec_local as secret

print (secret.host)

con = pymysql.connect(secret.host, secret.user, secret.pas, 'diplom', cursorclass=pymysql.cursors.DictCursor)
cursor = con.cursor()
query = "select * from data"
cursor.execute(query)
rows = cursor.fetchall()

print(rows[0])

data_to_

# def get_new_date():
#     con = pymysql.connect(secret.host, secret.user, secret.pas, 'diplom', cursorclass=pymysql.cursors.DictCursor)
#     cursor = con.cursor()
#     query = "select * from data ORDER BY id DESC limit 1"
#     cursor.execute(query)
#     rows = cursor.fetchall()
#     if len(rows)>0:
#         last_date = datetime.strptime(rows[0]['date'], '%Y-%m-%d').date()
#         new_date = last_date + timedelta(days=1)
#         return(new_date.strftime("%Y-%m-%d"))
#     else:
#         return ('2018-12-30')

