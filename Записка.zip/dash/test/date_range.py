from datetime import datetime as dt
import dash
import dash_html_components as html
import dash_core_components as dcc

external_stylesheets = ['https://codepen.io/chriddyp/pen/bWLwgP.css']

string_prefix = 'selected data range: '


app = dash.Dash(__name__, external_stylesheets=external_stylesheets)
app.layout = html.Div([
    dcc.DatePickerRange(
        id='my-date-picker-range',
        min_date_allowed=dt(2018, 11, 1),
        max_date_allowed=dt(2020, 2, 20),
        initial_visible_month=dt(2019, 10, 1),
        start_date=dt(2019, 10, 1),
        end_date=dt(2019, 11, 1),
    ),


    html.Div(id='output-container-date-picker-range')
])



@app.callback(
    dash.dependencies.Output('output-container-date-picker-range', 'children'),
    [dash.dependencies.Input('my-date-picker-range', 'start_date'),
     dash.dependencies.Input('my-date-picker-range', 'end_date')]
)

def update_output(start_date, end_date):
    string_prefix = 'selected data range: '
    if start_date is not None:
        start_date = dt.strptime(start_date.split('T')[0], '%Y-%m-%d')
        start_date_string = start_date.strftime('%Y-%m-%d')
        string_prefix = string_prefix + 'Start: ' + start_date_string + ' | '
    if end_date is not None:
        end_date = dt.strptime(end_date.split('T')[0], '%Y-%m-%d')
        end_date_string = end_date.strftime('%Y-%m-%d')
        string_prefix = string_prefix + 'End: ' + end_date_string
    if len(string_prefix) == len('selected data range: '):
        return 'Select a date to see it displayed here'
    else:
        return render_graf(start_date, end_date)
        # string_prefix

def render_graf(s, e):
    return html.Div(children=[
        html.Div(children='Dash: A web application framework for Python'),
        html.Div(children="Start_date: "+s.strftime('%Y-%m-%d')),
        html.Div(children="End_Date: "+e.strftime('%Y-%m-%d')),
        # html.Div(children="Разница в днях: " + (e.date()-s.date()).days),

        dcc.Graph(
            id='example-graph',
            figure={
                'data': [
                    {'x': ['2019.10.01', '2019.10.05'], 'y': [4, 1], 'type': 'bar', 'name': 'SF'},
                ],
                'layout': {'title': 'Dash Data Visualization'}
            }
        )
    ]),

if __name__ == '__main__':
    app.run_server(debug=True)