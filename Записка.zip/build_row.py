def build_row(df_tmp, d1):
    total_day_data = {
        'date': d1,
        'users': df_tmp.shape[0],
        'visits': df_tmp['visits'].sum(),
        'buyers': df_tmp[df_tmp['goals'] != 0.0].shape[0],
        'idle': df_tmp[df_tmp['goals'] == 0.0].shape[0],
        'goals': df_tmp['goals'].sum(),
        'revenue': round(df_tmp['revenue'].sum(), 2),
        'total_pageViews': df_tmp['pageViews'].sum(),
        # 'total_goals': df_tmp['goals'].sum(),
        'pageViews_per_user': round(df_tmp['pageViews'].sum() / df_tmp.shape[0], 2),
        'pageViews_per_buyers': round(df_tmp['pageViews'].sum() / df_tmp[df_tmp['goals'] != 0.0].shape[0], 2),
        'goals_per_user': round(df_tmp['goals'].sum() / df_tmp.shape[0], 2),
        'goals_per_buyers': round(df_tmp['goals'].sum() / df_tmp[df_tmp['goals'] != 0.0].shape[0], 2),
        'visit_per_user': round(df_tmp['visits'].sum() / df_tmp.shape[0], 2),
        'visit_per_buyers': round(df_tmp['visits'].sum() / df_tmp[df_tmp['goals'] != 0.0].shape[0], 2),
        'revenue_per_user_arpu': round(df_tmp['revenue'].sum() / df_tmp.shape[0], 2),
        'revenue_per_buyers_arppu': round(df_tmp['revenue'].sum() / df_tmp[df_tmp['goals'] != 0.0].shape[0], 2),
    }


    return total_day_data