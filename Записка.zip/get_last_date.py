import pymysql
from datetime import datetime, timedelta
import time

# import secret as secret

import sec_local as secret



def get_new_date():
    con = pymysql.connect(secret.host, secret.user, secret.pas, 'diplom', cursorclass=pymysql.cursors.DictCursor)
    cursor = con.cursor()
    query = "select * from data ORDER BY id DESC limit 1"
    cursor.execute(query)
    rows = cursor.fetchall()
    if len(rows)>0:
        last_date = datetime.strptime(rows[0]['date'], '%Y-%m-%d').date()
        new_date = last_date + timedelta(days=1)
        return(new_date.strftime("%Y-%m-%d"))
    else:
        return ('2018-12-30')

# print(get_new_date())
