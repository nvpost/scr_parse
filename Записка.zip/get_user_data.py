import requests
import pandas as pd
import time
from datetime import datetime, timedelta


import secret
import date_array
import build_row
import get_last_date
import sql_users_data

import sql

# date1 = '2020-02-01'
# date2 = date1
# date2 = '2018-11-01'
# d = '2020-02-01'

# d = get_last_date.get_new_date()



# dates = date_array.delta_date_foo(date1, date2)

metrics = """
ym:s:visits, 
ym:s:pageviews, 
ym:s:ecommercePurchases, 
ym:s:ecommerceRevenue, 
ym:s:sumGoalReachesAny, 
ym:s:bounceRate, 
ym:s:mobilePercentage,
ym:s:productBasketsPrice,
ym:s:productBasketsQuantity
"""
f_base="(`date`, `user_id`, `visits`, `pageviews`, `ecommercePurchases`, `ecommerceRevenue`, `sumGoalReachesAny`, `bounceRate`, `mobilePercentage`, `productBasketsPrice`, `productBasketsQuantity`)"

def make_requests(d):
    payload = {
        'metrics': metrics,
        'dimensions': 'ym:s:clientID',
        'date1': d,
        'date2': d,
        'limit': '20000',
        'ids': secret.id,
        'accuracy': 'full',
        'pretty': True,
    }
    r = requests.get('https://api-metrika.yandex.ru/stat/v1/data', params=payload, headers=secret.headers)
    data =r.json()

    print(data)

    day_load=[]
    for i in data['data']:
        row=[d]
        row.append(i['dimensions'][0]['name'])
        for j in i['metrics']:
            row.append(j)
        day_load.append(row)
    # day_load.append(d)
    print(day_load[0])
    # df_day = pd.DataFrame(day_load)
    # columns_names = {0: 'clientId', 1: 'visits', 2: 'pageViews', 3: 'purchases', 4: 'revenue', 5: 'goals'}
    # df_day.rename(columns=columns_names, inplace=True)

    # print(df_day)

    # df_day_scored = df_day[df_day['pageViews'] > 1]

    # aggregated_data = build_row.build_row(df_day_scored, d1)
    # sql.add_row_to_db(aggregated_data)

    sql_users_data.add_row_to_db(f_base, day_load)
    time.sleep(1)
    last_date = datetime.strptime(d, '%Y-%m-%d').date()
    new_date = (last_date + timedelta(days=1)).strftime("%Y-%m-%d")
    # nd = get_last_date.get_new_date()
    print('=========================== nd: ', d, ' ===========================')
    print('=========================== nd: ', new_date, ' ===========================')
    if new_date != '2020-02-20':
        make_requests(new_date)
    else:
        print('get_data: ', new_date)
        return



make_requests('2019-06-19')



