from datetime import datetime, timedelta


delta_date_ar=[]
def delta_date_foo(date1, date2):
    date_start = datetime.strptime(date1, '%Y-%m-%d').date()
    date_fin = datetime.strptime(date2, '%Y-%m-%d').date()

    deltadays = (date_fin - date_start).days+1
    print("days count: ",deltadays)
    nd=date_start
    for i in range(deltadays):
        row = {'date1': nd.strftime("%Y-%m-%d"), 'date2': nd.strftime("%Y-%m-%d")}
        nd = nd + timedelta(days=1)
        delta_date_ar.append(row)
    return(delta_date_ar)
