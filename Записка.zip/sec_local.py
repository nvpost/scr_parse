headers={'Authorization': 'OAuth AgAAAAAAoZrYAAYSJtZLiQ2JPk9DioLUfcB4za0'}
id = 3419323
host = 'localhost'
user = 'root'
pas = 'mysql'