import pymysql
import time

# import secret as secret

import sec_local as secret

con = pymysql.connect(secret.host, secret.user, secret.pas, 'diplom', cursorclass=pymysql.cursors.DictCursor)
cursor = con.cursor()


def add_row_to_db(values):
    print('values: ', values)
    vals=''
    fields = ''
    # create fields and values
    for i in values:
        fields = fields+ "`"+i+"`, "
        vals = vals + "'"+str(values[i])+"', "
    vals = vals[0:len(vals) - 2]
    fields = fields[0:len(fields) - 2]
    print(vals)
    print('fil', fields)
    cursor.execute("INSERT INTO data ({}) VALUES ({})".format(fields, vals))
    con.commit()

