import pymysql

# import secret as secret

import sec_local as secret

print(secret.pas)

con = pymysql.connect(secret.host, secret.user, secret.pas, 'diplom', cursorclass=pymysql.cursors.DictCursor)

cursor = con.cursor()

# query = """
# CREATE TABLE data (
#     `id` int NOT NULL AUTO_INCREMENT,
#     `date` text  NOT NULL,
#     `users` int  NOT NULL,
#     `visits` int  NOT NULL,
#     `buyers` double  NOT NULL,
#     `idle` double  NOT NULL,
#     `goals` double  NOT NULL,
#     `revenue` double  NOT NULL,
#     `total_pageViews` double  NOT NULL,
#     `pageViews_per_user` double  NOT NULL,
#     `pageViews_per_buyers` double  NOT NULL,
#     `goals_per_user` double  NOT NULL,
#     `goals_per_buyers` double  NOT NULL,
#     `visit_per_user` double  NOT NULL,
#     `visit_per_buyers` double  NOT NULL,
#     `revenue_per_user_arpu` double  NOT NULL,
#     `revenue_per_buyers_arppu` double NOT NULL,
#     PRIMARY KEY (`id`)
# ) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin
# AUTO_INCREMENT=1 ;
# """


# query = """
# CREATE TABLE users_data (
#     `id` int NOT NULL AUTO_INCREMENT,
#     `date` text  NOT NULL,
#     `user_id` text  NOT NULL,
#     `visits` int  NOT NULL,
#     `pageviews` double  NOT NULL,
#     `ecommercePurchases` double  NOT NULL,
#     `ecommerceRevenue` double  NOT NULL,
#     `sumGoalReachesAny` double  NOT NULL,
#     `bounceRate` double  NOT NULL,
#     `mobilePercentage` double  NOT NULL,
#     `productBasketsPrice` double  NOT NULL,
#     `productBasketsQuantity` double  NOT NULL,
#     PRIMARY KEY (`id`)
# ) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin
# AUTO_INCREMENT=1 ;
# """
cursor.execute(query)