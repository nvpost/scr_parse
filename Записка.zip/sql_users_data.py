import pymysql
import time

# import secret as secret

import sec_local as secret

con = pymysql.connect(secret.host, secret.user, secret.pas, 'diplom', cursorclass=pymysql.cursors.DictCursor)
cursor = con.cursor()


def add_row_to_db(fields, values_arr):
    vals=''
    # create fields and values

    # for i in values:
    #     vals = vals + "'"+str(i)+"', "
    # vals = vals[0:len(vals) - 2]

    # print('fields: ', fields)
    # print('values: ', type(values))
    # print('vals: ', vals)

    # for i in values_arr:
    #     vals = "', '".join(str(x) for x in i)
    #     vals = "'"+vals+"'"
    #     try:
    #         cursor.execute("INSERT INTO users_data {} VALUES ({})".format(fields, vals))
    #     except:
    #         print('error')
    #         continue
    # con.commit()

