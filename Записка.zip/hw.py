import os
cwd = os.getcwd()
import datetime

d = datetime.datetime.now().strftime("%Y-%m-%d-%H.%M.%S")
print('t:' +d)
print(cwd)
my_file = open("/root/diplom/data_to_base/s1.txt", "a")
my_file.write(d+'\n')
my_file.close()